<?php include('config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PHP and MySQL</title>
</head>
<body>
    <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere vel ea natus quis cupiditate! Consectetur debitis unde laborum, culpa placeat asperiores odio. Doloribus nam repudiandae fuga aliquam, eius doloremque ad!
    </p>
    
    <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere vel ea natus quis cupiditate! Consectetur debitis unde laborum, culpa placeat asperiores odio. Doloribus nam repudiandae fuga aliquam, eius doloremque ad!
    </p>
    <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere vel ea natus quis cupiditate! Consectetur debitis unde laborum, culpa placeat asperiores odio. Doloribus nam repudiandae fuga aliquam, eius doloremque ad!
    </p>
    <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere vel ea natus quis cupiditate! Consectetur debitis unde laborum, culpa placeat asperiores odio. Doloribus nam repudiandae fuga aliquam, eius doloremque ad!
    </p>
    <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere vel ea natus quis cupiditate! Consectetur debitis unde laborum, culpa placeat asperiores odio. Doloribus nam repudiandae fuga aliquam, eius doloremque ad!
    </p>
    <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere vel ea natus quis cupiditate! Consectetur debitis unde laborum, culpa placeat asperiores odio. Doloribus nam repudiandae fuga aliquam, eius doloremque ad!
    </p>
    <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere vel ea natus quis cupiditate! Consectetur debitis unde laborum, culpa placeat asperiores odio. Doloribus nam repudiandae fuga aliquam, eius doloremque ad!
    </p>

</body>
</html>




<!--  -->
1. All js Event Try
2. HTML, CSS and Bootstrap

Next Class 
============
1. JavaScript Form Validation
2. OOP Basic
3. Database a data Insert
4. View Data From database
5. Delete Data From database