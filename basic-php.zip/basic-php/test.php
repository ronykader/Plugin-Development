<?php 
    

    // echo 12598745;

    /*
    echo 12598745;
    echo 12598745;
    echo 12598745;
    echo 12598745;
    echo 12598745;
    */

    # echo 12598745;
    // echo 12598745;

    // $name = "Md.Tarikul Islam";
    // $name = "Rony Kader";

    // echo $name;


    // $content = "Lorem ipsum Bangladesh sit amet consectetur, adipisicing elit. Pariatur eos 
    //             assumenda et dolorem aperiam ipsum, fugit odio rem, accusantium molestias 
    //             aliquid deserunt blanditiis id impedit modi optio hic iste omnis cum esse
    //             porro magnam! Itaque, tenetur ab nemo blanditiis totam cupiditate,
    //             consectetur quis neque nihil alias quas quidem sed aspernatur animi
    //             ipsum possimus perspiciatis laborum porro reprehenderit nam fugiat";



    // echo $content;
    // echo $content;
    // echo $content;
    // echo $content;

    // $test = 123.5698;

    // echo gettype(123.222);

    // echo gettype();


    // $information = ['name' => 'Md.Tarikul Islam', 'address' => 'Dhaka Mirpur Bangladeh' ];


    // echo "<pre>";
    // print_r($information);
    // echo $information['name'];


    // function test($dynamic) {
    //     return $dynamic;
    // }

    // echo test("This content from dynamic value");

?>