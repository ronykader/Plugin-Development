<?php 
    // $a = 1;
    // echo $a;
    // echo "<br>";
    // echo $a;

// $x = 10;

// if ( $x < 10 ) {
//     echo "output is true";
// } elseif( $x <= 5 ) {
//     echo "Variable er man 5";
// } elseif ( $x <= 10 ) {
//     echo "Yes it's true";
// } else {
//     echo "output is false";
// }

// if ( ) {

// } elseif( ){

// } else {

// }

// $xyz = 50;

// switch( $xyz ) {
//     case 1: 
//         echo "true";
//         break;
//     case 50:
//         echo "sothik";
//         break;
//     default:
//         echo "False";
// }



// $x = 1;
// while( $x <= 10 ) {
//     echo $x ."<br>";
//     $x++;
// }


// $a = 1;
// do {
//     echo $a . "</br>";
//     $a++;
// } while( $a < 1 );


// for( $y = 1; $y < 10; $y++ ) {
//     echo $y ."</br>";
// }

