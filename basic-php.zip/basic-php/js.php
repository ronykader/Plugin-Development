<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Basic JavaScript</title>
</head>
<body>
    <!-- <form action="">

    
    </form> -->



    <button id="clickme" onmouseover="return customeFunction();" onmouseout="return custome2Function();">Click Me</button>

    <p id="test-area">Hello CodemanBD</p>
    <p id="test-area1">Hello CodemanBD</p>
    <p id="test-area2">Hello CodemanBD</p>
    <p id="test-area3">Hello CodemanBD</p>
    <p id="test-area4">Hello CodemanBD</p>

    <script>
        function customeFunction() {
            // console.log('Hello Bangladesh');
            // alert('Hello Bangladesh');
            var test = 'Hello CodemanBD';
                console.log(test);
                
        }



        function custome2Function() {

            // document.getElementById('test-area').innerHTML = 'Text Change';
            // alert('Hello Bangladesh');
            // document
        }
    </script>
</body>
</html>